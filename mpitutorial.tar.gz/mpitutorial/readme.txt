I was added on the branch for-the-fun-of-it. (joined manually)
I added that on the branch. (joined manually)
I was added on the main trunk. (joined manually)
I added that on the main-trunk. (joined manually)

